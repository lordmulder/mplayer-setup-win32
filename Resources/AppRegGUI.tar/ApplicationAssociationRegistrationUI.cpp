#include <tchar.h>
#include <Windows.h>
#include <Objbase.h>
#include <Shobjidl.h>

#define APP_TITLE _T("File Assocations Tool")
#define APP_REGISTRATION_NAME _T("MPlayerForWindowsV2")

int CALLBACK WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	OSVERSIONINFO verInfo;
	memset(&verInfo, 0, sizeof(OSVERSIONINFO));
	verInfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	
	if(GetVersionEx(&verInfo))
	{
		if(verInfo.dwMajorVersion < 6)
		{
			MessageBox(NULL, _T("Sorry, only supported on Windows Vista and later!"), APP_TITLE, MB_ICONEXCLAMATION | MB_TOPMOST);
			return 1;
		}
	}

	HRESULT hr = CoInitialize(NULL);
	if((hr != S_OK) && (hr != S_FALSE))
	{
		MessageBox(NULL, _T("Critical error: CoInitialize() has failed!"), APP_TITLE, MB_ICONSTOP | MB_TOPMOST);
		return 2;
	}

	int ret = 0;

	HRESULT res;
	IApplicationAssociationRegistrationUI *aarui;
	res = CoCreateInstance
	(
		CLSID_ApplicationAssociationRegistrationUI, 0,
		CLSCTX_INPROC_SERVER,
		IID_IApplicationAssociationRegistrationUI, (LPVOID*)&aarui
	);


	if (SUCCEEDED(res) && aarui != 0)
	{
		hr = aarui->LaunchAdvancedAssociationUI(APP_REGISTRATION_NAME);
		if(hr != S_OK)
		{
			MessageBox(NULL, _T("LaunchAdvancedAssociationUI() has failed!"), APP_TITLE, MB_ICONSTOP | MB_TOPMOST);
			ret = 3;
		}
		aarui->Release();
	}
	else
	{
		MessageBox(NULL, _T("ApplicationAssociationRegistrationUI not available!"), APP_TITLE, MB_ICONSTOP | MB_TOPMOST);
		ret = 4;
	}

	CoUninitialize();
	return ret;
}
